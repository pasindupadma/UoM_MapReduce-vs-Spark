DROP TABLE IF EXISTS DelayedFlights;

CREATE EXTERNAL TABLE DelayedFlights ( rowID bigint, Year int, Month int, DayofMonth int, DayOfWeek int, DepTime double, CRSDepTime int, ArrTime double, CRSArrTime int, UniqueCarrier string, FlightNum int, TailNum String, ActualElapsedTime double, CRSElapsedTime double, AirTime double, ArrDelay double, DepDelay double, Origin String, Dest String, Distance int, TaxiIn double, TaxiOut double, Cancelled int, CancellationCode String, Diverted int, CarrierDelay double, WeatherDelay double, NASDelay double, SecurityDelay double, LateAircraftDelay double ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' STORED AS TEXTFILE LOCATION "s3://239322-uom/hive/";


INSERT OVERWRITE DIRECTORY "s3://239322-uom/hive/Outputs/"
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
SELECT Year, SUM(CarrierDelay) AS carrier_delay, 
SUM(NASDelay) AS nas_delay,
SUM(WeatherDelay) AS weather_delay,
SUM(LateAircraftDelay) AS late_aircraft_delay,
SUM(SecurityDelay) AS security_delay
FROM DelayedFlights
WHERE Year >= 2003 AND Year <= 2010
GROUP BY Year;

-- Compute year wise carrier delay from 2003-2010
SELECT Year, SUM(CarrierDelay) AS carrier_delay
FROM DelayedFlights
WHERE Year >= 2003 AND Year <= 2010
GROUP BY Year;

-- Compute year wise NAS delay from 2003-2010
SELECT Year, SUM(NASDelay) AS nas_delay
FROM DelayedFlights
WHERE Year >= 2003 AND Year <= 2010
GROUP BY Year;

-- Compute year wise Weather delay from 2003-2010
SELECT Year, SUM(WeatherDelay) AS weather_delay
FROM DelayedFlights
WHERE Year >= 2003 AND Year <= 2010
GROUP BY Year;

-- Compute year wise late aircraft delay from 2003-2010
SELECT Year, SUM(LateAircraftDelay) AS late_aircraft_delay
FROM DelayedFlights
WHERE Year >= 2003 AND Year <= 2010
GROUP BY Year;

-- Compute year wise security delay from 2003-2010
SELECT Year, SUM(SecurityDelay) AS security_delay
FROM DelayedFlights
WHERE Year >= 2003 AND Year <= 2010
GROUP BY Year;


CREATE TABLE table_csv_export_data
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED as textfile
AS
select 'Year' as Year, 'carrier_delay' as carrier_delay, 'nas_delay' as nas_delay;

INSERT INTO table_csv_export_data 
SELECT Year, SUM(CarrierDelay) AS carrier_delay, SUM(NASDelay) AS nas_delay
FROM DelayedFlights
WHERE Year >= 2003 AND Year <= 2010
GROUP BY Year;

!hadoop fs -cat hdfs://servername/user/hive/warehouse/databasename/table_csv_export_data/* > ~/output.csv